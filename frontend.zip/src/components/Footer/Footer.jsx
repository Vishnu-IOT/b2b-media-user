import React from "react";
import { Link } from "react-router-dom";
import "./footer.css";

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="container site-footer__top">
        <div className="site-footer__brand">
          <div className="site-header__logo">
            <span className="site-header__logo-mark">V</span>
            <span className="site-header__logo-text">Vartha</span>
          </div>
          <p>
            Business media, stories and knowledge for the local business
            community.
          </p>
        </div>

        <div className="site-footer__col">
          <h4>Explore</h4>
          <Link to="/stories">Business Stories</Link>
          <Link to="/achievements">Achievements</Link>
          <Link to="/strategies">Strategies</Link>
          <Link to="/products">Products</Link>
          <Link to="/videos">Videos</Link>
        </div>
        <div className="site-footer__col">
          <h4>Resources</h4>
          <Link to="/resources?category=marketing">Marketing</Link>
          <Link to="/resources?category=gst">GST</Link>
          <Link to="/resources?category=msme">MSME</Link>
          <Link to="/resources?category=startup">Startup</Link>
        </div>
        <div className="site-footer__col">
          <h4>Community</h4>
          <Link to="/community">Business Q&amp;A</Link>
          <Link to="/enquiries">Supplier Enquiries</Link>
          <Link to="/register">Join the Network</Link>
        </div>
      </div>
      <div className="divider" />
      <div className="container site-footer__bottom">
        <p>© 2026 Vartha Business Network. All rights reserved.</p>
        <p>
          Business, tax and legal information is for guidance only — verify with
          official sources.
        </p>
      </div>
    </footer>
  );
}
