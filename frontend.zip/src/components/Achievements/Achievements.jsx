import React from "react";
import { Link } from "react-router-dom";
import useFetch from "../../hooks/useFetch";
import { achievementsApi } from "../../api/endpoints";
import AchievementRow from "./AchievementRow";
import { Loading, ErrorMessage, Empty } from "../common/StateMessage";
import "./achievements.css";

export function AchievementsFeed({ limit }) {
  const { data, loading, error, refetch } = useFetch(() => achievementsApi.list({ limit: limit || 20 }), [limit]);
  const items = (data && data.items) || [];

  if (loading) return <Loading />;
  if (error) return <ErrorMessage error={error} onRetry={refetch} />;
  if (!items.length) return <Empty>No achievements published yet.</Empty>;

  return (
    <div className="achv-rows">
      {items.map((a) => <AchievementRow achievement={a} key={a.id} />)}
    </div>
  );
}

export default function AchievementsPreview() {
  return (
    <section className="achv-section">
      <div className="container">
        <div className="section-head-row">
          <div>
            <p className="eyebrow">Recognitions</p>
            <h2 className="section-heading" style={{ fontSize: "clamp(26px,2.8vw,36px)" }}>Business Achievements</h2>
          </div>
          <Link to="/achievements" className="btn-link">See all achievements →</Link>
        </div>
        <AchievementsFeed limit={4} />
      </div>
    </section>
  );
}
