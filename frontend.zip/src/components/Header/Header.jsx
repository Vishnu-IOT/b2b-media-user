import React, { useEffect, useRef, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { businessApi, resourceCategoriesApi } from "../../api/endpoints";
import { fileUrl } from "../../api/client";
import "./header.css";

const MEGA = {
  Business: {
    description:
      "Company stories, growth, products and everything a business shares.",
    items: [
      {
        label: "Business Stories",
        to: "/stories",
        desc: "Growth journeys and company backgrounds.",
      },
      {
        label: "Achievements",
        to: "/achievements",
        desc: "Awards, certifications and milestones.",
      },
      {
        label: "Strategies",
        to: "/strategies",
        desc: "Marketing approaches and lessons learned.",
      },
      {
        label: "New Products",
        to: "/products",
        desc: "Upcoming and recently launched products.",
      },
      {
        label: "Supplier Enquiries",
        to: "/enquiries",
        desc: "Requirements businesses are looking to fill.",
      },
      {
        label: "Business Videos",
        to: "/videos",
        desc: "Company, product and introduction videos.",
      },
    ],
  },
  Community: {
    description:
      "Where businesses and professionals ask, answer and learn from each other.",
    items: [
      {
        label: "Business Q&A",
        to: "/community",
        desc: "Ask a question or help answer one.",
      },
    ],
  },
  Resources: {
    description: "Knowledge grouped by what local businesses actually need.",
    items: [], // filled dynamically from the real resource categories — see Header component
  },
};

const TOP_LEVEL = ["Business", "Community", "Resources"];

const MEGA_IMAGES = {
  Business: "/images/mega-menu/business1.jpg",
  Community: "/images/mega-menu/community1.avif",
  Resources: "/images/mega-menu/resources1.webp",
};

export default function Header() {
  const { user, logout } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [openPanel, setOpenPanel] = useState(null);
  const [mobileExpanded, setMobileExpanded] = useState(null);
  const [featured, setFeatured] = useState(null);
  const [resourceCategories, setResourceCategories] = useState([]);
  const closeTimer = useRef(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
  }, [menuOpen]);

  useEffect(() => {
    businessApi
      .list({ limit: 1 })
      .then((res) => setFeatured(res.items[0]))
      .catch(() => {});
    resourceCategoriesApi
      .list()
      .then(setResourceCategories)
      .catch(() => {});
  }, []);

  const openNow = (label) => {
    clearTimeout(closeTimer.current);
    setOpenPanel(label);
  };
  const scheduleClose = () => {
    closeTimer.current = setTimeout(() => setOpenPanel(null), 160);
  };

  return (
    <>
      <header
        className={`site-header ${scrolled ? "is-scrolled" : ""} ${openPanel ? "has-panel-open" : ""}`}
        onMouseLeave={scheduleClose}
      >
        <div className="site-header__inner container">
          <Link
            to="/"
            className="site-header__logo"
            onClick={() => {
              setMenuOpen(false);
              setOpenPanel(null);
            }}
          >
            <span className="site-header__logo-mark">V</span>
            <span className="site-header__logo-text">Vartha</span>
          </Link>

          <nav className="site-header__nav">
            <NavLink
              to="/"
              className={({ isActive }) =>
                "site-header__link" + (isActive ? " is-active" : "")
              }
            >
              Home
            </NavLink>
            {TOP_LEVEL.map((label) => (
              <button
                key={label}
                className={`site-header__link site-header__link--btn ${openPanel === label ? "is-active" : ""}`}
                onMouseEnter={() => openNow(label)}
                onClick={() => setOpenPanel(openPanel === label ? null : label)}
              >
                {label} <span className="site-header__caret">▾</span>
              </button>
            ))}
          </nav>

          <div className="site-header__actions">
            {user ? (
              <>
                <Link to="/account" className="site-header__text-link">
                  My Account
                </Link>
                <button className="site-header__text-link site-header-logout" onClick={logout}>
                  Log out
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="site-header__text-link">
                  Log in
                </Link>
                <Link
                  to="/register"
                  className="btn btn-accent site-header__join"
                >
                  Join
                </Link>
              </>
            )}
            <button
              className={`site-header__burger ${menuOpen ? "is-open" : ""}`}
              onClick={() => setMenuOpen((v) => !v)}
              aria-label="Menu"
            >
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>

        {/* Fullscreen mega panel */}
        {openPanel && (
          <div className="mega-panel" onMouseEnter={() => openNow(openPanel)}>
            <div className="container mega-panel__inner">
              <div className="mega-panel__main">
                <p className="mega-panel__eyebrow">{openPanel}</p>

                <p className="mega-panel__desc">
                  {MEGA[openPanel].description}
                </p>

                <div className="mega-panel__grid">
                  {(openPanel === "Resources"
                    ? resourceCategories.map((c) => ({
                        label: c.name,
                        to: `/resources?category=${c.slug}`,
                        desc:
                          c.description ||
                          `${c.postCount} resource${
                            c.postCount === 1 ? "" : "s"
                          } published`,
                      }))
                    : MEGA[openPanel].items
                  ).map((it) => (
                    <Link
                      key={it.label}
                      to={it.to}
                      className="mega-panel__item"
                      onClick={() => setOpenPanel(null)}
                    >
                      <span className="mega-panel__item-title">{it.label}</span>

                      <span className="mega-panel__item-desc">{it.desc}</span>
                    </Link>
                  ))}
                </div>

                {openPanel === "Resources" && (
                  <Link
                    to="/resources"
                    className="btn-link mega-panel__secondary"
                    onClick={() => setOpenPanel(null)}
                  >
                    View All Resources →
                  </Link>
                )}

                {MEGA[openPanel].secondaryLink && (
                  <Link
                    to={MEGA[openPanel].secondaryLink.to}
                    className="btn-link mega-panel__secondary"
                    onClick={() => setOpenPanel(null)}
                  >
                    {MEGA[openPanel].secondaryLink.label} →
                  </Link>
                )}
              </div>

              {/* Mega Menu Cover Image */}
              <div className="mega-panel__cover">
                <img src={MEGA_IMAGES[openPanel]} alt={`${openPanel}`} />
              </div>
            </div>
          </div>
        )}

        {/* Mobile drawer */}
        <div className={`mobile-nav ${menuOpen ? "is-open" : ""}`}>
          <NavLink
            to="/"
            className="mobile-nav__link"
            onClick={() => setMenuOpen(false)}
          >
            Home
          </NavLink>
          {TOP_LEVEL.map((label) => {
            const expanded = mobileExpanded === label;
            return (
              <div key={label} className="mobile-nav__group">
                <button
                  className="mobile-nav__link mobile-nav__link--toggle"
                  onClick={() => setMobileExpanded(expanded ? null : label)}
                >
                  {label} <span>{expanded ? "−" : "+"}</span>
                </button>
                {expanded && (
                  <div className="mobile-nav__submenu">
                    {(label === "Resources"
                      ? resourceCategories.map((c) => ({
                          label: c.name,
                          to: `/resources?category=${c.slug}`,
                        }))
                      : MEGA[label].items
                    ).map((it) => (
                      <Link
                        key={it.label}
                        to={it.to}
                        onClick={() => setMenuOpen(false)}
                      >
                        {it.label}
                      </Link>
                    ))}
                    {label === "Resources" && (
                      <Link to="/resources" onClick={() => setMenuOpen(false)}>
                        View All Resources
                      </Link>
                    )}
                    {MEGA[label].secondaryLink && (
                      <Link
                        to={MEGA[label].secondaryLink.to}
                        onClick={() => setMenuOpen(false)}
                      >
                        {MEGA[label].secondaryLink.label}
                      </Link>
                    )}
                  </div>
                )}
              </div>
            );
          })}
          {user ? (
            <>
              <Link
                to="/account"
                className="mobile-nav__link"
                onClick={() => setMenuOpen(false)}
              >
                My Account
              </Link>
              <button
                className="btn btn-outline mobile-nav__join"
                onClick={() => {
                  logout();
                  setMenuOpen(false);
                }}
              >
                Log out
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="mobile-nav__link"
                onClick={() => setMenuOpen(false)}
              >
                Log in
              </Link>
              <Link
                to="/register"
                className="btn btn-accent mobile-nav__join"
                onClick={() => setMenuOpen(false)}
              >
                Join the Network
              </Link>
            </>
          )}
        </div>
      </header>
    </>
  );
}
