import React from "react";
import { AchievementsFeed } from "../components/Achievements/Achievements";

export default function AchievementsPage() {
  return (
    <div className="page-shell container" style={{ paddingTop: 40, paddingBottom: 90 }}>
      <p className="eyebrow">Recognitions</p>
      <h1 className="section-heading" style={{ fontSize: "clamp(30px,3.6vw,46px)", marginBottom: 30 }}>Business Achievements</h1>
      <AchievementsFeed />
    </div>
  );
}
